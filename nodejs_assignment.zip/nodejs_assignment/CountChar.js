const sentence1 = "Hello everyone...!";
const sentence2 = "Myself Rohit Deshmukh.";
const sentence3 = "I am learning JavaScript..";

console.log(`Sentence 1: "${sentence1}" has ${sentence1.length} characters.`);
console.log(`Sentence 2: "${sentence2}" has ${sentence2.length} characters.`);
console.log(`Sentence 3: "${sentence3}" has ${sentence3.length} characters.`);