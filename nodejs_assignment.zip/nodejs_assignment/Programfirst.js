// Programfirst.js

const message1 = "Hello, this is my first Node.js program!";
const message2 = "I am excited to learn more about Node.js!";

const combinedMessage = message1 + " " + message2;
console.log(message1);
console.log(message1);
console.log(combinedMessage);